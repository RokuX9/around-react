# Project 10 - Around React

This project is about using React to recreate the last project, which was built with vanilla JS.
it uses hooks to add interactivity to the site.

## Technologies:
HTML, CSS, JS, React

## whats next?
adding login to the site

link to Github page: https://RokuX9.github.io/around-react
import React from "react";
const CurrentUserContext = React.createContext();
export default CurrentUserContext;
